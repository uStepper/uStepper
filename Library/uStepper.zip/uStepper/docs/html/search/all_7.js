var searchData=
[
  ['i2c',['I2C',['../uStepper_8cpp.html#a3216dd3022dcb4a4e82d44fd41509e8e',1,'I2C():&#160;uStepper.cpp'],['../uStepper_8h.html#a3216dd3022dcb4a4e82d44fd41509e8e',1,'I2C():&#160;uStepper.cpp']]],
  ['i2cfree',['I2CFREE',['../uStepper_8h.html#a46fd28b671402790a8b9c4c2dde700d8',1,'uStepper.h']]],
  ['i2cmaster',['i2cMaster',['../classi2cMaster.html',1,'i2cMaster'],['../classi2cMaster.html#a2d4c2077400ec94c157916804e9fdaae',1,'i2cMaster::i2cMaster()']]],
  ['initdecel',['INITDECEL',['../uStepper_8h.html#a0c1151fb74132a2a24a1483ca529d511',1,'uStepper.h']]],
  ['initialdecelsteps',['initialDecelSteps',['../classuStepper.html#ac8e3d3157ea9b11dec50354396e67ef6',1,'uStepper']]],
  ['intfreq',['INTFREQ',['../uStepper_8h.html#a2d6d8ed93a3b37e34993ff25b5dfa6f3',1,'uStepper.h']]]
];
