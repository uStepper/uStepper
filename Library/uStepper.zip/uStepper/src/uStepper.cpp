/********************************************************************************************
* 	 	File: 		uStepper.cpp 															*
*		Version:    0.1                                             						*
*      	date: 		january 3rd, 2016                                    					*
*      	Author: 	Thomas Hørring Olsen                                   					*
*                                                   										*	
*********************************************************************************************
*			            uStepper class 					   									*
* 																							*
*	This file contains the implementation of the class methods, incorporated in the  		*
*	uStepper arduino library. The library is used by instantiating an uStepper object 		*
*	by calling either of the two overloaded constructors: 									*
*																							*
*		example:																			*
*																							*
*		uStepper stepper; 																	*
*																							*
*		OR 																					*
*																							*
*		uStepper stepper(500, 2000);														*
*																							*
*	The first instantiation above creates a uStepper object with default maximum speed 		*
*	and acceleration (1000 steps/s and 1000steps/s^2 respectively). 						*
*	The second instantiation overwrites the default settings of maximum speed and 			*
*	acceleration (in this case 500 steps/s and 2000 steps/s^2, respectively);				*
*																							*
*	after instantiation of the object, the object setup function should be called within 	*
*	arduino's setup function:																*
*																							*
*		example:																			*
*																							*
*		uStepper stepper;																	*
*																							*
*		void setup()																		*
*		{																					*
*			stepper.setup();																*
*		} 																					*
*																							*
*		void loop()																			*
*		{																					*
*																							*
*		}																					*
*																							*
*	After this, the library is ready to control the motor!									*
*																							*
*********************************************************************************************
*								TO DO:														*
*	- Implement Doxygen comments															*
*	- Review comments																		*
*	- Fix getSpeed method - This method does not currently work !							*
*																							*
*********************************************************************************************
*	(C) 2016																				*
*																							*
*	ON Development IVS																		*
*	www.on-development.com 																	*
*	administration@on-development.com 														*
*																							*
*	The code contained in this file is released under the following open source license:	*
*																							*
*			Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International			*
* 																							*
* 	The code in this file is provided without warranty of any kind - use at own risk!		*
* 	neither ON Development IVS nor the author, can be held responsible for any damage		*
* 	caused by the use of the code contained in this file ! 									*
*                                                                                           *
********************************************************************************************/

#include <uStepper.h>
#include <Arduino.h>
#include <Wire.h>
#include <util/delay.h>

uStepper *pointer;

extern "C" {
	void TIMER2_COMPA_vect(void)
	{
		asm volatile("jmp _AccelerationAlgorithm \n\t");	//Execute the acceleration profile algorithm
	}
}

uStepperTemp::uStepperTemp(void)
{

}

float uStepperTemp::getTemp(void)
{
	float T = 0.0;
	float Vout = 0.0;
	float NTC = 0.0;

	Vout = analogRead(TEMP)*0.0048876;//0.0048876=5V/1023
	NTC = ((R*5.0)/Vout)-R;//the current NTC resistance
	NTC = log(NTC);
	T = A + B*NTC + C*NTC*NTC*NTC;    //Steinhart-Hart equation
	T = 1.0/T;

	return T - 273.15;
}

uStepperEncoder::uStepperEncoder(void)
{
	Wire.begin();
	Wire.setClock(400000UL);
}

float uStepperEncoder::getSpeed(void)
{
	uint32_t count;
	float Time;
	float speed;

	count = micros();
	speed = this->getAngle();
	count = micros() - count;
	speed = this->getAngle() - speed;

	Time = (float)count;
	Time /= 1000000.0;
	speed /= Time;

	return speed;
}

float uStepperEncoder::getAngle()
{
	float angle;

	angle = (float)readTwoBytes(ANGLE);

	return angle*0.087890625;
}

uint16_t uStepperEncoder::getStrength()
{
	return this->readTwoBytes(MAGNITUDE);
}

uint8_t uStepperEncoder::getAgc()
{
	return this->readOneByte(AGC);
}

uint8_t uStepperEncoder::detectMagnet()
{
	uint8_t ret;

	ret = this->readOneByte(STATUS);

	ret &= 0x38;					//For some reason the encoder returns random values on reserved bits. Therefore we make sure reserved bits are cleared before checking the reply !

	if(ret == 0x08)
	{
		return 1;					//magnet too strong
	}

	else if(ret == 0x10)
	{
		return 2;					//magnet too weak
	}

	else if(ret == 0x20)
	{
		return 0;					//magnet detected and within limits
	}

	return 3;						//Something went horribly wrong !
}

uint16_t uStepperEncoder::readTwoBytes(uint8_t addr)
{
	uint16_t retVal;
 	uint8_t low;

	/* Read Low Byte */
	Wire.beginTransmission(ENCODERADDR);
	Wire.write(addr);
	Wire.endTransmission();
	Wire.requestFrom(ENCODERADDR, 1);
	while(Wire.available() == 0);
	retVal = (uint16_t)Wire.read();

	/* Read High Byte */  
	Wire.beginTransmission(ENCODERADDR);
	Wire.write(addr + 1);
	Wire.endTransmission();
	Wire.requestFrom(ENCODERADDR, 1);

	while(Wire.available() == 0);

	low= Wire.read();

	retVal <<= 8;

	return retVal | (uint16_t)low;
}

uint8_t uStepperEncoder::readOneByte(uint8_t addr)
{
	uint8_t retVal;
	
	Wire.beginTransmission(ENCODERADDR);
	Wire.write(addr);
	Wire.endTransmission();
	Wire.requestFrom(ENCODERADDR, 1);
	while(Wire.available() == 0);
	retVal = Wire.read();

	return retVal;
}

uStepper::uStepper(void)
{
	int i;

	this->state = STOP;

	this->setMaxAcceleration(2000.0);
	this->setMaxVelocity(1500.0);

	pointer = this;

	pinMode(DIR, OUTPUT);
	pinMode(STEP, OUTPUT);
	pinMode(ENA, OUTPUT);	
}

uStepper::uStepper(float accel, float vel)
{
	int i;

	this->state = STOP;

	this->setMaxAcceleration(accel);
	this->setMaxVelocity(vel);

	pointer = this;

	pinMode(DIR, OUTPUT);
	pinMode(STEP, OUTPUT);
	pinMode(ENA, OUTPUT);
}

void uStepper::setMaxAcceleration(float accel)
{
	if(accel > 16416.0)
	{
		this->acceleration = 16416.0;				//Limit acceleration, in order to ensure the multiplier variable only occupies the lower two bytes !
	}

	else if(accel < 1.0)
	{
		this->acceleration = 1.0;					//Limit acceleration in order to ensure the multiplier variable does not become smaller than 2^-32, and hereby get truncated to 0.
	}
	
	else
	{
		this->acceleration = accel;
	}

	this->stopTimer();			//Stop timer so we dont fuck up stuff !
	this->multiplier = (uint32_t)(((float)((uint64_t)1 << 32))*(this->acceleration/(INTFREQ*INTFREQ)));	//Recalculate multiplier variable, used by the acceleration algorithm since acceleration has changed!
	if(this->state != STOP)
	{
		if(this->continous == 1)	//If motor was running continously
		{
			this->runContinous(this->direction);	//We should make it run continously again
		}
		else					//If motor still needs to perform some steps
		{
			if(totalSteps != 0)
			{
				this->moveSteps(this->totalSteps - this->currentStep, this->direction, this->hold);	//we should make sure it gets to execute these steps	
			}
			
		}
	}
}

float uStepper::getMaxAcceleration(void)
{
	return this->acceleration;
}

void uStepper::setMaxVelocity(float vel)
{
	if(vel < 0.5005)
	{
		this->velocity = 0.5005;			//Limit velocity in order to not overflow delay variable
	}

	else if(vel > 32000.0)
	{
		this->velocity = 32000.0;			//limit velocity in order to not underflow delay variable
	}

	else
	{
		this->velocity = vel;
	}

	this->stopTimer();			//Stop timer so we dont fuck up stuff !
	this->cruiseDelay = (uint32_t)((INTFREQ/this->velocity) - 0.5);	//Calculate cruise delay, so we dont have to recalculate this in the interrupt routine
	
	if(this->state != STOP)		//If motor was running, we should make sure it runs again
	{
		if(this->continous == 1)	//If motor was running continously
		{
			this->runContinous(this->direction);	//We should make it run continously again
		}
		else					//If motor still needs to perform some steps
		{
			if(totalSteps != 0)
			{
				this->moveSteps(this->totalSteps - this->currentStep, this->direction, this->hold);	//we should make sure it gets to execute these steps	
			}
			
		}
	}
}

float uStepper::getMaxVelocity(void)
{
float curVel;

	return this->velocity;
/*
	curVel = ((float)this->exactDelay)/((float)((uint32_t)1 << 16));	//Convert the current step delay from Q16.16 to float
	curVel = 1.0/(curVel/INTFREQ);						//use this to calculate current velocity

	Serial.print("s: ");
	Serial.print(this->state);
	Serial.print(" ed: ");
	Serial.println(this->exactDelay);
	Serial.print(curVel);
	Serial.print(" d: ");
	Serial.print(this->delay);
	Serial.print(" i: ");
	Serial.print(this->initialDecelSteps);
	Serial.print(" a: ");
	Serial.print(this->accelSteps);
	Serial.print(" c: ");
	Serial.print(this->cruiseSteps);
	Serial.print(" d: ");
	Serial.print(this->decelSteps);
	Serial.print(" cur: ");
	Serial.print(this->totalSteps);
	Serial.print(" m: ");
	Serial.print(this->encoder.getStrength());
	Serial.print(" Temp: ");
	Serial.println(this->temp.getTemp());*/

}

void uStepper::runContinous(bool dir)
{
	float curVel;

	this->continous = 1;			//Set continous variable to 1, in order to let the interrupt routine now, that the motor should run continously
	
	this->stopTimer();				//Stop interrupt timer, so we don't fuck up stuff !

	if(state != STOP)										//if the motor is currently running and we want to move the opposite direction, we need to decelerate in order to change direction.
	{
		curVel = ((float)this->exactDelay + 1.0)/((float)((uint32_t)1 << 16));	//Convert the current step delay from Q16.16 to float
		curVel = 1.0/(curVel/INTFREQ);						//use this to calculate current velocity

		if(dir != digitalRead(DIR))							//If motor is currently running the opposite direction as desired
		{
			this->state = INITDECEL;							//We should decelerate the motor to full stop before accelerating the speed in the opposite direction
			this->initialDecelSteps = (uint32_t)(((curVel*curVel))/(2.0*this->acceleration));		//the amount of steps needed to bring the motor to full stop. (S = (V^2 - V0^2)/(2*-a)))
			this->accelSteps = (uint32_t)((this->velocity*this->velocity)/(2.0*this->acceleration));			//Number of steps to bring the motor to max speed (S = (V^2 - V0^2)/(2*a)))
			this->direction = dir;
		}
		else												//If the motor is currently rotating the same direction as the desired direction
		{
			if(curVel > this->velocity)						//If current velocity is greater than desired velocity
			{
				this->state = INITDECEL;						//We need to decelerate the motor to desired velocity
				this->initialDecelSteps = (uint32_t)(((this->velocity*this->velocity) - (curVel*curVel))/(-2.0*this->acceleration));		//Number of steps to bring the motor down from current speed to max speed (S = (V^2 - V0^2)/(2*-a)))
				this->accelSteps = 0;						//No acceleration phase is needed
			}

			else if(curVel < this->velocity)					//If the current velocity is less than the desired velocity
			{
				this->state = ACCEL;							//Start accelerating
				this->accelSteps = (uint32_t)(((this->velocity*this->velocity) - (curVel*curVel))/(2.0*this->acceleration));	//Number of Steps needed to accelerate from current velocity to full speed
			}

			else											//If motor is currently running at desired speed
			{
				this->state = CRUISE;						//We should just run at cruise speed
			}
		}
	}

	else																						//If motor is currently stopped (state = STOP)
	{
		this->state = ACCEL;																		//Start accelerating
		digitalWrite(DIR, dir);																	//Set the motor direction pin to the desired setting
		this->accelSteps = (velocity*velocity)/(2.0*acceleration);								//Number of steps to bring the motor to max speed (S = (V^2 - V0^2)/(2*a)))
		
		this->exactDelay = (uint32_t)(((float)((uint32_t)1 << 16))*(INTFREQ/sqrt(2.0*this->acceleration)) - 1.0);	//number of interrupts before the first step should be performed.
	}
	this->delay = (uint16_t)((this->exactDelay + 0x00008000) >> 16);														//Truncate exactDelay variable as we cannot perform fractional steps

	this->startTimer();																			//start timer so we can perform steps
	this->enableMotor();																			//Enable motor
}

void uStepper::moveSteps(uint32_t steps, bool dir, bool holdMode)
{
	float curVel;

	this->stopTimer();					//Stop interrupt timer so we dont fuck stuff up !

	this->direction = dir;				//Set direction variable to the desired direction of rotation for the interrupt routine
	this->hold = holdMode;				//Set the hold variable to desired hold mode (block motor or release motor after end movement) for the interrupt routine
	this->totalSteps = steps;			//Load the desired number of steps into the totalSteps variable for the interrupt routine
	this->continous = 0;				//Set continous variable to 0, since the motor should not run continous
	this->currentStep = 0;				//Reset the currentstep variable, as we start on a new movement

	if(state != STOP)					//if the motor is currently running and we want to move the opposite direction, we need to decelerate in order to change direction.
	{
		curVel = ((float)this->exactDelay + 1.0)/((float)((uint32_t)1 << 16));		//Convert the current step delay from Q16.16 to float
		curVel = 1.0/(curVel/INTFREQ);								//Use this to calculate current velocity

		if(dir != digitalRead(DIR))									//If current direction is different from desired direction
		{
			this->state = INITDECEL;									//We should decelerate the motor to full stop
			this->initialDecelSteps = (uint32_t)((curVel*curVel)/(2.0*this->acceleration));		//the amount of steps needed to bring the motor to full stop. (S = (V^2 - V0^2)/(2*-a)))
			this->accelSteps = (uint32_t)((this->velocity * this->velocity)/(2.0*this->acceleration));									//Number of steps to bring the motor to max speed (S = (V^2 - V0^2)/(2*a)))
			this->totalSteps += this->initialDecelSteps;				//Add the steps used for initial deceleration to the totalSteps variable, since we moved this number of steps, passed the initial position, and therefore need to move this amount of steps extra, in the desired direction

			if(this->accelSteps > (this->totalSteps >> 1))			//If we need to accelerate for longer than half of the total steps, we need to start decelerating before we reach max speed
			{
				this->accelSteps = this->decelSteps = (this->totalSteps >> 1);	//Accelerate and decelerate for the same amount of steps (half the total steps)
				this->accelSteps += this->totalSteps - this->accelSteps - this->decelSteps;				//If there are still a step left to perform, due to rounding errors, do this step as an acceleration step	
			}
			else
			{
				this->decelSteps = this->accelSteps;					//If top speed is reached before half the total steps are performed, deceleration period should be same length as acceleration period
				this->cruiseSteps = this->totalSteps - this->accelSteps - this->decelSteps; 			//Perform remaining steps, as cruise steps
			}
		}
		else							//If the motor is currently rotating the same direction as desired, we dont necessarily need to decelerate
		{
			if(curVel > this->velocity)	//If current velocity is greater than desired velocity
			{
				this->state = INITDECEL;	//We need to decelerate the motor to desired velocity
				this->initialDecelSteps = (uint32_t)(((this->velocity*this->velocity) - (curVel*curVel))/(-2.0*this->acceleration));		//Number of steps to bring the motor down from current speed to max speed (S = (V^2 - V0^2)/(2*-a)))
				this->accelSteps = 0;	//No acceleration phase is needed
				this->decelSteps = (uint32_t)((this->velocity*this->velocity)/(2.0*this->acceleration));	//Number of steps needed to decelerate the motor from top speed to full stop

				if(this->totalSteps <= (this->initialDecelSteps + this->decelSteps))
				{
					this->cruiseSteps = 0;
				}
				else
				{
					this->cruiseSteps = steps - this->initialDecelSteps - this->decelSteps;					//Perform remaining steps as cruise steps
				}

				
			}

			else if(curVel < this->velocity)	//If current velocity is less than desired velocity
			{
				this->state = ACCEL;			//Start accelerating
				this->accelSteps = (uint32_t)(((this->velocity*this->velocity) - (curVel*curVel))/(2.0*this->acceleration));	//Number of Steps needed to accelerate from current velocity to full speed
				
				if(this->accelSteps > (this->totalSteps >> 1))			//If we need to accelerate for longer than half of the total steps, we need to start decelerating before we reach max speed
				{
					this->accelSteps = this->decelSteps = (this->totalSteps >> 1);	//Accelerate and decelerate for the same amount of steps (half the total steps)
					this->accelSteps += this->totalSteps - this->accelSteps - this->decelSteps;				//If there are still a step left to perform, due to rounding errors, do this step as an acceleration step	
					this->cruiseSteps = 0;
				}
				else
				{
					this->decelSteps = this->accelSteps;					//If top speed is reached before half the total steps are performed, deceleration period should be same length as acceleration period
					this->cruiseSteps = this->totalSteps - this->accelSteps - this->decelSteps; 			//Perform remaining steps, as cruise steps
				}

				this->cruiseSteps = steps - this->accelSteps - this->decelSteps;	//Perform remaining steps as cruise steps
				this->initialDecelSteps = 0;								//No initial deceleration phase needed
			}

			else						//If current velocity is equal to desired velocity
			{
				this->state = CRUISE;	//We are already at desired speed, therefore we start at cruise phase
				this->decelSteps = (uint32_t)((this->velocity*this->velocity)/(2.0*this->acceleration));	//Number of steps needed to decelerate the motor from top speed to full stop
				this->accelSteps = 0;	//No acceleration phase needed
				this->initialDecelSteps = 0;		//No initial deceleration phase needed
				if(this->decelSteps >= this->totalSteps)
				{
					this->cruiseSteps = 0;
				}
				else
				{
					this->cruiseSteps = steps - this->decelSteps;	//Perform remaining steps as cruise steps
				}
			}
		}
	}
	
	else								//If motor is currently at full stop (state = STOP)
	{
		digitalWrite(DIR, dir);			//Set direction pin to desired direction
		this->state = ACCEL;
		this->accelSteps = (uint32_t)((this->velocity * this->velocity)/(2.0*this->acceleration));	//Number of steps to bring the motor to max speed (S = (V^2 - V0^2)/(2*a)))
		this->initialDecelSteps = 0;		//No initial deceleration phase needed

		if(this->accelSteps > (steps >> 1))	//If we need to accelerate for longer than half of the total steps, we need to start decelerating before we reach max speed
		{
			this->cruiseSteps = 0; 		//No cruise phase needed
			this->accelSteps = this->decelSteps = (steps >> 1);				//Accelerate and decelerate for the same amount of steps (half the total steps)
			this->accelSteps += steps - this->accelSteps - this->decelSteps;	//if there are still a step left to perform, due to rounding errors, do this step as an acceleration step	
		}

		else								
		{
			this->decelSteps = this->accelSteps;	//If top speed is reached before half the total steps are performed, deceleration period should be same length as acceleration period
			this->cruiseSteps = steps - this->accelSteps - this->decelSteps;	//Perform remaining steps as cruise steps
		}

		this->exactDelay = (uint32_t)(((float)((uint32_t)1 << 16))*(INTFREQ/sqrt(2.0*this->acceleration)) - 1.0);	//number of interrupts before the first step should be performed.
	}
	
	this->delay = (uint16_t)((this->exactDelay + 0x00008000)>> 16);		//Truncate the exactDelay variable, since we cant perform fractional steps

	this->startTimer();									//start timer so we can perform steps
	this->enableMotor();									//Enable motor driver
}

uint32_t uStepper::hardStop(bool holdMode)
{
	this->stopTimer();			//Stop interrupt timer, since we shouldn't perform more steps
	this->hold = holdMode;

	if(state != STOP)
	{
		this->state = STOP;			//Set current state to STOP
		this->currentStep = this->totalSteps = 0;

		this->startTimer();
	}

	else
	{
		if(holdMode == SOFT)
		{
			this->disableMotor();
		}
		
		else if (holdMode == HARD)
		{
			this->enableMotor();
		}
	}
}

void uStepper::softStop(bool holdMode)
{
	float curVel;

	this->stopTimer();			//Stop interrupt timer, since we shouldn't perform more steps
	this->hold = holdMode;		

	if(state != STOP)
	{
		curVel = ((float)this->exactDelay)/((float)((uint32_t)1 << 16));		//Convert the current step delay from Q16.16 to float
		curVel = 1.0/(curVel/INTFREQ);								//Use this to calculate current velocity

		this->decelSteps = (uint32_t)((curVel*curVel)/(2.0*this->acceleration));		//Number of steps to bring the motor down from current speed to max speed (S = (V^2 - V0^2)/(2*-a)))	
		this->accelSteps = this->initialDecelSteps = this->cruiseSteps = 0;	//Reset amount of steps in the different phases	
		this->state = DECEL;

		this->exactDelay = (uint32_t)(((float)((uint32_t)1 << 16))*(INTFREQ/sqrt((curVel*curVel) + (2.0*this->acceleration))) - 1.0);	//number of interrupts before the first step should be performed.
		this->delay = (uint16_t)((this->exactDelay + 0x00008000) >> 16);		//Truncate the exactDelay variable, since we cant perform fractional steps

		this->currentStep = this->totalSteps = 0;

		this->startTimer();
	}

	else
	{
		if(holdMode == SOFT)
		{
			this->disableMotor();
		}
		
		else if (holdMode == HARD)
		{
			this->enableMotor();
		}
	}
}

void uStepper::setup(void)
{
	TCCR2B &= ~((1 << CS20) | (1 << CS21) | (1 << CS22) | (1 << WGM22));
	TCCR2A &= ~((1 << WGM20) | (1 << WGM21));
	TCCR2B |= (1 << CS21);				//Enable timer with prescaler 8. interrupt base frequency ~ 7.8125kHz
	TCCR2A |= (1 << WGM21);				//Switch timer 2 to CTC mode, to adjust interrupt frequency
	OCR2A = 60;							//Change top value to 60 in order to obtain an interrupt frequency of 33.333kHz
}

void uStepper::startTimer(void)
{
	TCNT2 = 0;							//Clear counter value, to make sure we get correct timing
	TIFR2 |= (1 << OCF2A);				//Clear compare match interrupt flag, if it is set.
	TIMSK2 |= (1 << OCIE2A);			//Enable compare match interrupt

	sei();
}

void uStepper::stopTimer(void)
{
	TIMSK2 &= ~(1 << OCF2A);			//disable compare match interrupt
}

void uStepper::enableMotor(void)
{
	digitalWrite(ENA, LOW);				//Enable motor driver
}

void uStepper::disableMotor(void)
{
	digitalWrite(ENA, HIGH);			//Disable motor driver
}

bool uStepper::getCurrentDirection(void)
{
	return this->direction;
}

bool uStepper::getMotorState(void)
{
	if(this->state != STOP)
	{
		return 1;		//Motor running
	}

	return 0;			//Motor not running
}