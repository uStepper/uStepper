/********************************************************************************************
* 	 	File: 		uStepper.h 																*
*		Version:    0.1                                             						*
*      	date: 		january 3rd, 2016                                    					*
*      	Author: 	Thomas Hørring Olsen                                   					*
*                                                   										*	
*********************************************************************************************
*			            uStepper class header			   									*
* 																							*
* 	This file contains the definitions for the uStepper class 								*
*																							*
*********************************************************************************************
*								TO DO:														*
*	- Implement Doxygen comments															*
*	- Remove unused variables																*
*																							*
*********************************************************************************************
*	(C) 2016																				*
*																							*
*	ON Development IVS																		*
*	www.on-development.com 																	*
*	administration@on-development.com 														*
*																							*
*	The code contained in this file is released under the following open source license:	*
*																							*
*			Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International			*
* 																							*
* 	The code in this file is provided without warranty of any kind - use at own risk!		*
* 	neither ON Development IVS nor the author, can be held responsible for any damage		*
* 	caused by the use of the code contained in this file ! 									*
*                                                                                           *
********************************************************************************************/

#ifndef _USTEPPER_H_
#define _USTEPPER_H_

#ifndef __AVR_ATmega328P__
#error !!This library only supports the ATmega328p MCU!!
#endif

#include <inttypes.h>
#include <avr/io.h>

#define STOP 1
#define ACCEL 2
#define CRUISE 3
#define DECEL 4
#define INITDECEL 5
#define INTFREQ 32800.0f              //frequency of interrupt routine
#define CW 0
#define CCW 1
#define HARD 1
#define SOFT 0

#define ENCODERADDR 0x36

#define ANGLE 0x0E
#define ANGLE_MSB 0x0E
#define ANGLE_LSB 0x0F
#define STATUS 0x0B
#define AGC 0x1A
#define MAGNITUDE 0x1B
#define MAGNITUDE_MSB 0x1B
#define MAGNITUDE_LSB 0x1C

#define R 4700.0 //4k7 resistor in series with 4k7 NTC
#define A 0.001295752996237  //T1 = 5 degree celcius
#define B 0.000237488365866  //T2 = 50 degree Celcius
#define C 0.000000083423218  //T3 = 105 degree Celcius

//extern "C" void test(void);
extern "C" void TIMER2_COMPA_vect(void) __attribute__ ((signal,naked));

class uStepperTemp
{
public:
	uStepperTemp();
	float getTemp();
private:
};

class uStepperEncoder
{
public:
	uStepperEncoder();
	float getSpeed(void);
	float getAngle();
	uint16_t getStrength();
	uint8_t getAgc();
	uint8_t detectMagnet();

private:
	uint16_t readTwoBytes(uint8_t addr);
	uint8_t readOneByte(uint8_t addr);
};

class uStepper
{
private:
	uint8_t enablePinMask;				//Address offset: 0				//NOT USED
	uint8_t stepPinMask;				//Address offset: 1				//NOT USED
	uint8_t dirPinMask;					//Address offset: 2				//NOT USED
	uint16_t cruiseDelay;				//Q16.0, //Address offset: 3
	float velocity;						//Address offset: 5
	float acceleration;					//Address offset: 9
	uint16_t delay;						//Q16.0, //Address offset: 13
	uint32_t exactDelay;				//Q16.16, //Address offset: 15
	uint32_t multiplier;				//Q0.32 //Address offset: 19
	uint8_t state;						//Address offset: 23
	uint32_t accelSteps;				//Address offset: 24
	uint32_t decelSteps;				//Address offset: 28
	uint32_t initialDecelSteps;			//Address offset: 32
	uint32_t cruiseSteps;				//Address offset: 36
	uint32_t currentStep;				//Address offset: 40
	uint32_t totalSteps;				//Address offset: 44
	bool continous;						//Address offset: 48
	bool hold;							//Address offset: 49
	bool direction;						//Address offset: 50
	uint8_t enablePinPort;				//Address offset: 51			//NOT USED
	uint8_t stepPinPort;				//address offset: 52			//NOT USED
	uint8_t dirPinPort;					//address offset: 53			//NOT USED

	friend void TIMER2_COMPA_vect(void) __attribute__ ((signal));
	void startTimer(void);
	void stopTimer(void);
	void enableMotor(void);
	void disableMotor(void);

public:
	uStepperTemp temp;
	uStepperEncoder encoder;

	uStepper(float accel, float vel);
	uStepper(void);
	void setMaxAcceleration(float accel);
	float getMaxAcceleration(void);
	void setMaxVelocity(float vel);
	float getMaxVelocity(void);
	void runContinous(bool dir);
	void moveSteps(uint32_t steps, bool dir, bool holdMode);
	uint32_t hardStop(bool holdMode);
	void softStop(bool holdMode);
	void setup(void);
	bool getCurrentDirection(void);
	bool getMotorState(void);
};

#endif