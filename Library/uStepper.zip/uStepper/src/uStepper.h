/********************************************************************************************
* 	 	File: 		uStepper.h 																*
*		Version:    0.2.0                                           						*
*      	date: 		March 3rd, 2016	                                    					*
*      	Author: 	Thomas Hørring Olsen                                   					*
*                                                   										*	
*********************************************************************************************
*			            uStepper class header			   									*
* 																							*
* 	This file contains the definitions for the uStepper class 								*
*																							*
*********************************************************************************************
*								TO DO:														*
*	- Implement Doxygen comments															*
*																							*
*********************************************************************************************
*	(C) 2016																				*
*																							*
*	ON Development IVS																		*
*	www.on-development.com 																	*
*	administration@on-development.com 														*
*																							*
*	The code contained in this file is released under the following open source license:	*
*																							*
*			Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International			*
* 																							*
* 	The code in this file is provided without warranty of any kind - use at own risk!		*
* 	neither ON Development IVS nor the author, can be held responsible for any damage		*
* 	caused by the use of the code contained in this file ! 									*
*                                                                                           *
********************************************************************************************/

/**	\file uStepper.h
*	\brief Function prototypes and definitions for the uStepper library
*	
*	This file contains class and function prototypes for the library, aswell as 
*	necessary constants and global variables.
*	
*	\author Thomas Hørring Olsen (thomas@ustepper.com)
*	\bug No known bugs.
*/

#ifndef _USTEPPER_H_
#define _USTEPPER_H_

#ifndef __AVR_ATmega328P__
#error !!This library only supports the ATmega328p MCU!!
#endif

#include <inttypes.h>
#include <avr/io.h>

#define STOP 1					/**< Value to put in state variable in order to indicate that the motor should not be running */
#define ACCEL 2					/**< Value to put in state variable in order to indicate that the motor should be accelerating */
#define CRUISE 4				/**< Value to put in state variable in order to indicate that the motor should be decelerating */
#define DECEL 8					/**< Value to put in state variable in order to indicate that the motor should be cruising at constant speed with no acceleration */
#define INITDECEL 16			/**< Value to put in state variable in order to indicate that the motor should be decelerating to full stop before changing direction */
#define INTFREQ 32830.0f        /**< Frequency of interrupt routine, in which the delays for the stepper algorithm is calculated */ 
#define CW 0					/**< Value to put in direction variable in order for the stepper to turn clockwise */
#define CCW 1					/**< Value to put in direction variable in order for the stepper to turn counterclockwise */
#define HARD 1					/**< Value to put in hold variable in order for the motor to block when it is not running */
#define SOFT 0					/**< Value to put in hold variable in order for the motor to \b not block when it is not running */

#define ENCODERADDR 0x36		/**< I2C address of the encoder chip */

#define ANGLE 0x0E				/**< Address of the register, in the encoder chip, containing the 8 least significant bits of the stepper shaft angle */
#define STATUS 0x0B				/**< Address of the register, in the encoder chip, containing information about wether a magnet has been detected or not */
#define AGC 0x1A				/**< Address of the register, in the encoder chip, containing information about the current gain value used in the encoder chip. This value should preferably be around 127 (Ideal case!) */
#define MAGNITUDE 0x1B			/**< Address of the register, in the encoder chip, containing the 8 least significant bits of magnetic field strength measured by the encoder chip */

#define R 4700.0 				/**< The NTC resistor used for measuring temperature, is placed in series with a 4.7 kohm resistor. This is used to calculate the temperature */

/**
*	Coefficients needed by the Steinhart-hart equation in order to find the temperature of the NTC (and hereby the temperature of the motor driver)
*	from the current resistance of the NTC resistor. The coefficients are calculated for the following 3 operating points:
*
*	A: T = 5 degree Celsius
*
*	B: T = 50 degree Celsius
*
*	C: T = 105 degree Celsius
*
*	The Steinhart-Hart equation is described at the following link:
*
*	https://en.wikipedia.org/wiki/Steinhart%E2%80%93Hart_equation#Developers_of_the_equation
*
*/

#define A 0.001295752996237  	
#define B 0.000237488365866  /**< See description of A */
#define C 0.000000083423218  /**< See description of A */


extern "C" void TIMER2_COMPA_vect(void) __attribute__ ((signal,naked));

/**
*	\brief Prototype of class for the temperature sensor 
*
*	This class enables the user of the library to access the temperature sensor
*	on the uStepper board.
*	This class can be instantiated as a standalone object if this is the only feature
*	on the uStepper required by the programmers specific application.
*/

class uStepperTemp
{
public:
	
	/**
	*	\brief Constructor
	*	
	*	This is the constructor of the temperature sensor class, and should be 
	*	used in order to instantiate a temperature sensor object as follows:
	*
	*	\code{.cpp}
	*		uStepperTemp temp;
	*	\endcode
	*	
	*	\param void
	*/

	uStepperTemp(void);
	
	/**
	*	
	*
	*
	*/

	float getTemp(void);
private:
};

class uStepperEncoder
{
public:
	uStepperEncoder(void);
	float getAngle(void);
	uint16_t getStrength(void);
	uint8_t getAgc(void);
	uint8_t detectMagnet(void);

private:
	uint16_t readTwoBytes(uint8_t addr);
	uint8_t readOneByte(uint8_t addr);
};

class uStepper
{
private:
	uint16_t cruiseDelay;				//Address offset: 0
	float velocity;						//Address offset: 2
	float acceleration;					//Address offset: 6
	uint16_t delay;						//Address offset: 10
	float multiplier;					//Address offset: 12
	float exactDelayDecel;				//Address offset: 16
	uint8_t state;						//Address offset: 20
	uint32_t accelSteps;				//Address offset: 21
	uint32_t decelSteps;				//Address offset: 25
	uint32_t initialDecelSteps;			//Address offset: 29
	uint32_t cruiseSteps;				//Address offset: 33
	uint32_t currentStep;				//Address offset: 37
	uint32_t totalSteps;				//Address offset: 41
	bool continous;						//Address offset: 45
	bool hold;							//Address offset: 46
	bool direction;						//Address offset: 47
	int64_t stepsSinceReset;			//Address offset: 48
	float exactDelay;					//Address offset: 56

	friend void TIMER2_COMPA_vect(void) __attribute__ ((signal));
	void startTimer(void);
	void stopTimer(void);
	void enableMotor(void);
	void disableMotor(void);

public:
	uStepperTemp temp;
	uStepperEncoder encoder;

	uStepper(float accel, float vel);
	uStepper(void);
	void setMaxAcceleration(float accel);
	float getMaxAcceleration(void);
	void setMaxVelocity(float vel);
	float getMaxVelocity(void);
	void runContinous(bool dir);
	void moveSteps(uint32_t steps, bool dir, bool holdMode);
	uint32_t hardStop(bool holdMode);
	void softStop(bool holdMode);
	void setup(void);
	bool getCurrentDirection(void);
	bool getMotorState(void);
	int64_t getStepsSinceReset(void);
};

#endif