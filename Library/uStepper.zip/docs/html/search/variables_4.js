var searchData=
[
  ['hold',['hold',['../classuStepper.html#a4099233d63e894e8a8e364da8334c129',1,'uStepper']]]
];
