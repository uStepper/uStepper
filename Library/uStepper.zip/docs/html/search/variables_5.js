var searchData=
[
  ['i2c',['I2C',['../uStepper_8cpp.html#a3216dd3022dcb4a4e82d44fd41509e8e',1,'I2C():&#160;uStepper.cpp'],['../uStepper_8h.html#a3216dd3022dcb4a4e82d44fd41509e8e',1,'I2C():&#160;uStepper.cpp']]],
  ['initialdecelsteps',['initialDecelSteps',['../classuStepper.html#ac8e3d3157ea9b11dec50354396e67ef6',1,'uStepper']]]
];
