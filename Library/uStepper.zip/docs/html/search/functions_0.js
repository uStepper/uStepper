var searchData=
[
  ['begin',['begin',['../classi2cMaster.html#af639b1fb501c7530afdca5e87a56168f',1,'i2cMaster']]]
];
