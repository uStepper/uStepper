var searchData=
[
  ['getagc',['getAgc',['../classuStepperEncoder.html#a8a4a9e8dab1412c67de52b4454050d3e',1,'uStepperEncoder']]],
  ['getangle',['getAngle',['../classuStepperEncoder.html#abf760d7949e75977bf11bce48256283c',1,'uStepperEncoder']]],
  ['getanglemoved',['getAngleMoved',['../classuStepperEncoder.html#a29117f4952ff99ba53b90b842f4e69f1',1,'uStepperEncoder']]],
  ['getcurrentdirection',['getCurrentDirection',['../classuStepper.html#a3df44604dec260335d84eded6aacfe91',1,'uStepper']]],
  ['getmaxacceleration',['getMaxAcceleration',['../classuStepper.html#a352e4b96324adfe1feb66ab4f88c3745',1,'uStepper']]],
  ['getmaxvelocity',['getMaxVelocity',['../classuStepper.html#a1e88bdd345aba07f23409df7d7f93a89',1,'uStepper']]],
  ['getmotorstate',['getMotorState',['../classuStepper.html#abf677a4d4dd2902c55295fdb4b91bd3f',1,'uStepper']]],
  ['getspeed',['getSpeed',['../classuStepperEncoder.html#a8812beadc9bec6f4e321d281d9b6ea79',1,'uStepperEncoder']]],
  ['getstatus',['getStatus',['../classi2cMaster.html#a20091cd125f847e2cf50d0c7373adaa0',1,'i2cMaster']]],
  ['getstepssincereset',['getStepsSinceReset',['../classuStepper.html#aeb787bb58affb568cc583dd19fb7e5f8',1,'uStepper']]],
  ['getstrength',['getStrength',['../classuStepperEncoder.html#a26b81725b7a995fed98de0fcdd614b1f',1,'uStepperEncoder']]],
  ['gettemp',['getTemp',['../classuStepperTemp.html#a9ddadd3aadbd94e0f0290ebccf05ae2d',1,'uStepperTemp']]]
];
