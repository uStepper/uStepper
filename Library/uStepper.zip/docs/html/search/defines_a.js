var searchData=
[
  ['soft',['SOFT',['../uStepper_8h.html#a1b44ecf82561bec987fa3c07632335a4',1,'uStepper.h']]],
  ['start',['START',['../uStepper_8h.html#a3018c7600b7bb9866400596a56a57af7',1,'uStepper.h']]],
  ['status',['STATUS',['../uStepper_8h.html#a59279bee44f34d08b3cbf3a89fb0d8d9',1,'uStepper.h']]],
  ['stop',['STOP',['../uStepper_8h.html#ae19b6bb2940d2fbe0a79852b070eeafd',1,'uStepper.h']]]
];
